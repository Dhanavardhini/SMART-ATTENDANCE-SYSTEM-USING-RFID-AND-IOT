import React from 'react'
import ParentRegisterPage from '../../pages/ParentPages/ParentRegisterPage'

function ParentRegister() {
  return (
    <>
      <ParentRegisterPage/>
    </>
  )
}

export default ParentRegister
