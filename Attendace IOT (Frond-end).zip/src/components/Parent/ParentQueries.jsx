import React from 'react'
import ParentQueriesPage from '../../pages/ParentPages/ParentQueriesPage'

function ParentQueries() {
  return (
    <>
      <ParentQueriesPage/>
    </>
  )
}

export default ParentQueries
