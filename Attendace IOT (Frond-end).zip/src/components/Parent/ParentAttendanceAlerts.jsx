import React from 'react'
import ParentAttendanceAlertsPage from '../../pages/ParentPages/ParentAttendanceAlertsPage'

function ParentAttendanceAlerts() {
  return (
    <>
      <ParentAttendanceAlertsPage/>
    </>
  )
}

export default ParentAttendanceAlerts
