import React from 'react'
import SendNotificationsPage from '../../pages/TeacherPages/SendNotificationsPage'

function SendNotifications() {
  return (
    <>
      <SendNotificationsPage/>
    </>
  )
}

export default SendNotifications
