import React from 'react'
import TeacherLoginPage from '../../pages/TeacherPages/TeacherLoginPage'

function TeacherLogin() {
  return (
    <>
      <TeacherLoginPage/>
    </>
  )
}

export default TeacherLogin
