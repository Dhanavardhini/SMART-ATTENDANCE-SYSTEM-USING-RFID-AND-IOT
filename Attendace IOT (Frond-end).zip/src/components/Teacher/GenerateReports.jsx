import React from 'react'
import GenerateReportsPage from '../../pages/TeacherPages/GenerateReportsPage'

function GenerateReports() {
  return (
    <>
      <GenerateReportsPage/>
    </>
  )
}

export default GenerateReports
