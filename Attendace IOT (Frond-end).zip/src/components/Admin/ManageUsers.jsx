import React from 'react'
import ManageUsersPage from '../../pages/AdminPages/ManageUsersPage'

function ManageUsers() {
  return (
    <>
      <ManageUsersPage/>
    </>
  )
}

export default ManageUsers
