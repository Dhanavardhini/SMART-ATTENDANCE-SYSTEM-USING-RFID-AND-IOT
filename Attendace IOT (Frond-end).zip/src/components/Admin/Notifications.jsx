import React from 'react'
import NotificationsPage from '../../pages/AdminPages/NotificationsPage'

function Notifications() {
  return (
    <div>
      <NotificationsPage/>
    </div>
  )
}

export default Notifications
