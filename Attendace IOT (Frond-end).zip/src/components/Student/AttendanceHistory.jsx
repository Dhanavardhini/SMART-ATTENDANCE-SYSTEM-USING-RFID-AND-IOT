import React from 'react'
import AttendanceHistoryPage from '../../pages/StudentPages/AttendanceHistoryPage'

function AttendanceHistory() {
  return (
    <>
      <AttendanceHistoryPage/>
    </>
  )
}

export default AttendanceHistory
