import React from 'react'
import StudentRegistrationPage from '../../pages/StudentPages/StudentRegistrationPage'

function StudentRegistration() {
  return (
    <>
      <StudentRegistrationPage/>
    </>
  )
}

export default StudentRegistration
