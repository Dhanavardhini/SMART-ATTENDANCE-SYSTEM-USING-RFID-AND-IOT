import React from 'react'
import AttendanceCorrectionPage from '../../pages/StudentPages/AttendanceCorrectionPage'

function AttendanceCorrection() {
  return (
    <>
      <AttendanceCorrectionPage/>
    </>
  )
}

export default AttendanceCorrection
