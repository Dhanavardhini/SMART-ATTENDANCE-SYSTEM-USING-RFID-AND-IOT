import React from 'react'
import StudentDashboardPage from '../../pages/StudentPages/StudentDashboardPage'

function StudentDashboard() {
  return (
    <>
    <StudentDashboardPage/>
    </>
  )
}

export default StudentDashboard
