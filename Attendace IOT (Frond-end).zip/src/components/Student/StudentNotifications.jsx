import React from 'react'
import StudentNotificationsPage from '../../pages/StudentPages/StudentNotificationsPage'

function StudentNotifications() {
  return (
    <>
      <StudentNotificationsPage/>
    </>
  )
}

export default StudentNotifications
