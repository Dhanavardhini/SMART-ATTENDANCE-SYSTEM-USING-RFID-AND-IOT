import React from 'react'
import ParentDashboardPage from '../../pages/ParentPages/ParentDashboardPage'

function ParentDashboard() {
  return (
    <>

    <ParentDashboardPage/>
      
    </>
  )
}

export default ParentDashboard
