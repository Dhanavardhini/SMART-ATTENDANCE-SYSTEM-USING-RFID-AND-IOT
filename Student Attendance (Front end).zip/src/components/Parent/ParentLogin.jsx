import React from 'react'
import ParentLoginPage from '../../pages/ParentPages/ParentLoginPage'

function ParentLogin() {
  return (
    <div>
      <ParentLoginPage/>
    </div>
  )
}

export default ParentLogin
// http://localhost/student_attendance_iot/controllers/api/user/get/studentlogin.php