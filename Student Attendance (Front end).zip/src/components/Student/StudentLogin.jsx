import React from 'react'
import StudentLoginPage from '../../pages/StudentPages/StudentLoginPage'

function StudentLogin() {
  return (
    <>
      <StudentLoginPage/>
    </>
  )
}

export default StudentLogin
