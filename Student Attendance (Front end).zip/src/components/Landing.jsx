import React from 'react'
import LandingPage from '../pages/LandingPage'

function Landing() {
  return (
    <div>
      <LandingPage/>
    </div>
  )
}

export default Landing
