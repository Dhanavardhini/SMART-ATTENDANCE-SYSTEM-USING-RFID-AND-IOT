import React from 'react'
import ViewClassAttendancePage from '../../pages/TeacherPages/ViewClassAttendancePage'


function ViewClassAttendance() {
  return (
    <>
      <ViewClassAttendancePage/>
    </>
  )
}

export default ViewClassAttendance
