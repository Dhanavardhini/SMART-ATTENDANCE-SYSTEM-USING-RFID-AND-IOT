import React from 'react'
import MarkManualAttendancePage from '../../pages/TeacherPages/MarkManualAttendancePage'

function MarkManualAttendance() {
  return (
    <>
      <MarkManualAttendancePage/>
    </>
  )
}

export default MarkManualAttendance
