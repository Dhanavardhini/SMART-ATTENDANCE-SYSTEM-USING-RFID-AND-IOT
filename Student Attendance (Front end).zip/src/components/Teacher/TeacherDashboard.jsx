import React from 'react'
import TeacherDashboardPage from '../../pages/TeacherPages/TeacherDashboardPage'

function TeacherDashboard() {
  return (
    <TeacherDashboardPage/>
  )
}

export default TeacherDashboard
