import React from 'react'
import TeacherRegisterPage from '../../pages/TeacherPages/TeacherRegisterPage'


export default function TeacherRegister (){
    return(
        <>
        <TeacherRegisterPage/>
        </>
    )
}


