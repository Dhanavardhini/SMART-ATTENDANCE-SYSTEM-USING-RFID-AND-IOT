import React from 'react'
import ManageClassesPage from '../../pages/AdminPages/ManageClassesPage';

function ManageClasses() {
  return (
    <>
      <ManageClassesPage/>
    </>
  )
}

export default ManageClasses;
