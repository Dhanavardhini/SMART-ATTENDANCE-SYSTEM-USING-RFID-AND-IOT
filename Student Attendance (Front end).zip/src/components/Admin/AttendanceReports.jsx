import React from 'react'
import AttendanceReportsPage from '../../pages/AdminPages/AttendanceReportsPage'

function AttendanceReports() {
  return (
    <>
     <AttendanceReportsPage/> 
    </>
  )
}

export default AttendanceReports
