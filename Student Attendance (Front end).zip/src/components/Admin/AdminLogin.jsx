import React from 'react'
import AdminLoginPage from '../../pages/AdminPages/AdminLoginPage'

const AdminLogin = () => {
  return (
    <div>
      <AdminLoginPage/>
    </div>
  )
}

export default AdminLogin
