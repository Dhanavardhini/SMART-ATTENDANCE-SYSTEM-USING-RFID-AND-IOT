import React from 'react'
import AdminDashboardPage from '../../pages/AdminPages/AdDashboardPage'

function AdDashboard() {
  return (
    <>
      <AdminDashboardPage/>
    </>
  )
}

export default AdDashboard
