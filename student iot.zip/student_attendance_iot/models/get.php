<?php
include_once '../../../../config/database.php';

class Get
{ 
    public $conn;

    function __construct()
    {
        $db = new Database();
        $this->conn = $db->connect();
    }

    
    private function handleResponse($statusCode, $message) 
    {
        http_response_code($statusCode);
        echo json_encode(['error' => $message]);
        exit();
    }

   
// -----------------------------------------

public function studentLogin($email, $password) 
{
    // Prepare query to fetch user
    $query = "SELECT * FROM student_register WHERE email = ?";
    $stmt = mysqli_prepare($this->conn, $query);

    if (!$stmt) {
        return ["success" => false, "message" => "Failed to prepare statement"];
    }

    // Bind email parameter
    mysqli_stmt_bind_param($stmt, 's', $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Check if user exists
    if ($row = mysqli_fetch_assoc($result)) {
        // Verify hashed password
        if (password_verify($password, $row["password"])) {
            return ["success" => true, "message" => "Login successful"];
        } else {
            return ["success" => false, "message" => "Invalid email or password"];
        }
    } else {
        return ["success" => false, "message" => "Invalid email or password"];
    }
}

   
// -------------------

public function teacherLogin($email, $password) 
{
    // Prepare query to fetch user
    $query = "SELECT * FROM teacher_register WHERE email = ?";
    $stmt = mysqli_prepare($this->conn, $query);

    if (!$stmt) {
        return ["success" => false, "message" => "Failed to prepare statement"];
    }

    // Bind email parameter
    mysqli_stmt_bind_param($stmt, 's', $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Check if user exists
    if ($row = mysqli_fetch_assoc($result)) {
        // Verify hashed password
        if (password_verify($password, $row["password"])) {
            return ["success" => true, "message" => "Login successful"];
        } else {
            return ["success" => false, "message" => "Invalid email or password"];
        }
    } else {
        return ["success" => false, "message" => "Invalid email or password"];
    }
}



// ---------------------------
   
public function parentLogin($email, $password) 
{
    // Fetch user by email
    $query = "SELECT * FROM parent_register WHERE email = ?"; 
    $stmt = mysqli_prepare($this->conn, $query);

    if (!$stmt) {
        return ['error' => 'Failed to prepare statement'];
    }

    mysqli_stmt_bind_param($stmt, 's', $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // If user found, verify password
    if ($row = mysqli_fetch_assoc($result)) {
        if (password_verify($password, $row['password'])) {
            mysqli_stmt_close($stmt);
            return ['success' => 'Parent login successful'];
        } else {
            mysqli_stmt_close($stmt);
            return ['error' => 'Invalid email or password'];
        }
    } else {
        mysqli_stmt_close($stmt);
        return ['error' => 'Invalid email or password'];
    }
}

  

}

    
    
    
?>

