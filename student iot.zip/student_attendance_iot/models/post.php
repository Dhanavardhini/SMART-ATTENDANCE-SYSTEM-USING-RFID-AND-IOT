<?php
include_once '../../../../config/database.php';

class Post
{
    public $conn;
    public $response;
    function __construct()
    {
        $db = new Database();
        $this->conn = $db->connect();
    }

    // ------------------------------
    // public function TeacherRegister($name,$email,$password)
    // {
    //      $insert = "INSERT INTO teacher_register(name,email,password)  VALUES (?,?,?)";
    //      $stmt = mysqli_prepare($this->conn, $insert);
 
    //      if (!$stmt) {
    //          return ["message" => "Query preparation error: " . mysqli_error($this->conn)];
    //      }
 
    //      mysqli_stmt_bind_param($stmt, "sss", $name,$email,$password);
    //      $result = mysqli_stmt_execute($stmt);
 
    //      if ($result) {
    //          return ["message" => "Teacher Register successfully"];
    //      } else {
    //          return ["message" => "Teacher Register failed"];
    //      }
    // }

    public function TeacherRegister($name, $email, $password)
{
    $insert = "INSERT INTO teacher_register(name, email, password) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($this->conn, $insert);

    if (!$stmt) {
        return ["message" => "Query preparation error: " . mysqli_error($this->conn)];
    }

    // Bind parameters (hashed password)
    mysqli_stmt_bind_param($stmt, "sss", $name, $email, $password);
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        return ["message" => "Teacher registered successfully"];
    } else {
        return ["message" => "Teacher registration failed"];
    }
}


    // -----------------------------


public function StudentRegister($name, $email, $password)
{
    // Hash password for security
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Prepare the SQL query
    $insert = "INSERT INTO student_register (name, email, password) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($this->conn, $insert);

    if (!$stmt) {
        return ["success" => false, "message" => "Query preparation error: " . mysqli_error($this->conn)];
    }

    // Bind parameters
    mysqli_stmt_bind_param($stmt, "sss", $name, $email, $hashedPassword);
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        return ["success" => true, "message" => "Student registered successfully"];
    } else {
        return ["success" => false, "message" => "Student registration failed: " . mysqli_error($this->conn)];
    }
}

    // -------------------------------------

  
    public function ParentRegister($name, $email, $password)
{
    // Hash the password before storing it
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $insert = "INSERT INTO parent_register(name, email, password) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($this->conn, $insert);

    if (!$stmt) {
        return ["message" => "Query preparation error: " . mysqli_error($this->conn)];
    }

    mysqli_stmt_bind_param($stmt, "sss", $name, $email, $hashedPassword);
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        return ["message" => "Parent registered successfully"];
    } else {
        return ["message" => "Parent registration failed"];
    }
}

}
?> 
