<?php
// Define paths to required files
$modelsPath = '../../../../models/post.php';
$headersPath = '../../../../config/header.php';

// Check if required files exist and include them
if (!file_exists($modelsPath) || !file_exists($headersPath)) {
    handleError(500, 'Required files are missing');
}

// Require the necessary files
require_once $modelsPath;
require_once $headersPath;

// Function to handle errors and send response
function handleError($statusCode, $message) {
    http_response_code($statusCode);
    echo json_encode(['error' => $message]);
    exit();
}

// Decode the incoming JSON data
$data = json_decode(file_get_contents('php://input'));

// Check if the data is valid
if (!$data) {
    handleError(400, 'Invalid JSON or empty request body');
}

// Validate required fields
if (!isset($data->name, $data->email, $data->password)) {
    handleError(400, 'Missing required fields: name, email, or password');
}

// Create object and call the function
$obj = new Post();
$result = $obj->ParentRegister($data->name, $data->email, $data->password);

// Handle errors
if (!$result || isset($result['error'])) {
    handleError(500, 'Internal server error for Parent Register');
}

// Send response
echo json_encode($result);
?>
