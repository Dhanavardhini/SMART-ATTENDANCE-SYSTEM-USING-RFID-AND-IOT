<?php
// Define paths to required files
$modelsPath = '../../../../models/post.php';
$headersPath = '../../../../config/header.php';

// Check if required files exist and include them
if (!file_exists($modelsPath) || !file_exists($headersPath)) {
    handleError(500, 'Required files are missing');
}

// Require the necessary files
require_once $modelsPath;
require_once $headersPath;

// Function to handle errors and send response
function handleError($statusCode, $message) {
    http_response_code($statusCode);
    echo json_encode(['error' => $message]);
    exit();
}

// Decode the incoming JSON data
$data = json_decode(file_get_contents('php://input'));

// Check if the data is valid
if (!$data) {
    handleError(400, 'Invalid JSON or empty request body');
}

if (!isset($data->name, $data->email, $data->password)) {
    handleError(400, 'Missing required fields: name, email, or password');
}

// Hash the password before saving it
$hashedPassword = password_hash($data->password, PASSWORD_DEFAULT);

$obj = new Post();

// Insert teacher data with hashed password
$result = $obj->TeacherRegister($data->name, $data->email, $hashedPassword);

// Handle errors
if ($result === false) {
    handleError(500, 'Internal server error for teacher Register');
}

// Send the result
echo json_encode($result);
?>
