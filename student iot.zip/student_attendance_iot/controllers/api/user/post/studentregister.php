

<?php
// Set response headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");

// Define paths to required files
$modelsPath = '../../../../models/post.php';
$headersPath = '../../../../config/header.php';

// Function to handle errors and send response
function handleError($statusCode, $message) {
    http_response_code($statusCode);
    echo json_encode(["success" => false, "message" => $message]);
    exit();
}

// Check if required files exist and include them
if (!file_exists($modelsPath) || !file_exists($headersPath)) {
    handleError(500, "Required files are missing");
}

require_once $modelsPath;
require_once $headersPath;

// Decode the incoming JSON data
$data = json_decode(file_get_contents("php://input"));

if (!$data) {
    handleError(400, "Invalid JSON or empty request body");
}

// Check for missing fields
if (!isset($data->name, $data->email, $data->password)) {
    handleError(400, "Missing required fields: name, email, or password");
}

// Create an instance of Post class
$obj = new Post();

// Call the StudentRegister function
$result = $obj->StudentRegister($data->name, $data->email, $data->password);

// Handle errors
if ($result["success"] === false) {
    handleError(500, $result["message"]);
}

// Send success response
echo json_encode($result);
?>
