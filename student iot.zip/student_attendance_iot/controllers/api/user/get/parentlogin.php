<?php

// Define paths to required files
$modelsPath = '../../../../models/get.php';
$headersPath = '../../../../config/header.php';

// Check if required files exist
if (!file_exists($modelsPath) || !file_exists($headersPath)) {
    respondWithError(500, 'Required files are missing');
}

require_once $modelsPath;
require_once $headersPath;

// Decode JSON data
$data = json_decode(file_get_contents('php://input'));

// Validate input fields
if (!isset($data->email) || !isset($data->password)) {
    respondWithError(400, 'Parent email and password are required');
}

$email = $data->email;
$password = $data->password;

// Initialize database object
$obj = new Get();

// Check parent login
$result = $obj->parentLogin($email, $password);

// Handle errors
if (isset($result['error'])) {
    respondWithError(401, $result['error']);
}

// Return success response
echo json_encode($result);

/**
 * Function to handle errors and send JSON response
 *
 * @param int    $statusCode HTTP status code
 * @param string $message    Error message
 */
function respondWithError($statusCode, $message) {
    http_response_code($statusCode);
    echo json_encode(['error' => $message]);
    exit();
}
?>
