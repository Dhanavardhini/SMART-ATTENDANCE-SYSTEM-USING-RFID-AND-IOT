

<?php
// Set response headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");

// Define paths to required files
$modelsPath = '../../../../models/get.php';
$headersPath = '../../../../config/header.php';

// Function to handle errors and send response
function respondWithError($statusCode, $message) {
    http_response_code($statusCode);
    echo json_encode(["success" => false, "message" => $message]);
    exit();
}

// Check if required files exist
if (!file_exists($modelsPath) || !file_exists($headersPath)) {
    respondWithError(500, "Required files are missing");
}

require_once $modelsPath;
require_once $headersPath;

// Decode JSON request
$data = json_decode(file_get_contents("php://input"));

if (!isset($data->email) || !isset($data->password)) {
    respondWithError(400, "Email and password are required");
}

// Create an instance of Get class
$obj = new Get();
$result = $obj->studentLogin($data->email, $data->password);

// Handle login response
if (!$result["success"]) {
    respondWithError(401, $result["message"]);
}

// Send success response
echo json_encode($result);
?>

